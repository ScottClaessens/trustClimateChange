# Shuffling several apps
