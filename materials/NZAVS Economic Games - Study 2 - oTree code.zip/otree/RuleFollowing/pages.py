from . import models
from ._builtin import Page, WaitPage
from otree.api import Currency as c, currency_range
from .models import Constants
import json
import random
from random import sample, choice
import time

from otree.models_concrete import ParticipantToPlayerLookup, RoomToSession


def vars_for_all_templates(self):
    return {'game_number': self.participant.vars['game_number']}


class BasePage(Page):
    timer_text = 'Please complete all 8 tasks within this time:'

    def get_timeout_seconds(self):
        return self.participant.vars['expiry'] - time.time()

    def before_next_page(self):
        if self.timeout_happened:
            self.participant.vars['timeout_happened'] = True
            self.participant.vars['timeout_game_number'] = self.participant.vars['game_number']


class rfIntro(BasePage):
    def is_displayed(self):
        return self.participant.vars['expiry'] \
               - time.time() > 3 and not self.participant.vars[
            'timeout_happened'] and not self.participant.vars[
            'simulated'] and self.round_number == 1

    def vars_for_template(self):
        return {'counterbalancing': self.participant.vars["rfCounterbalancing"]}


class rfComp(BasePage):
    form_model = 'player'
    form_fields = ['comprehension']

    def is_displayed(self):
        return self.participant.vars['expiry'] \
               - time.time() > 3 and not self.participant.vars[
            'timeout_happened'] and not self.participant.vars[
            'simulated'] and self.round_number == 1

    def vars_for_template(self):
        return {'counterbalancing': self.participant.vars["rfCounterbalancing"]}


class rfComp2(BasePage):
    def vars_for_template(self):
        return {
            'counterbalancing': self.participant.vars["rfCounterbalancing"],
            'comp': self.player.comprehension
        }

    def is_displayed(self):
        return self.participant.vars['expiry'] \
               - time.time() > 3 and not self.participant.vars[
            'timeout_happened'] and not self.participant.vars[
            'simulated'] and self.round_number == 1


class rfDecision(BasePage):
    form_model = 'player'
    form_fields = ['rfBreakRule']

    def is_displayed(self):
        return self.participant.vars['expiry'] \
               - time.time() > 3 and not self.participant.vars[
            'timeout_happened'] and not self.participant.vars[
            'simulated']

    def before_next_page(self):
        if self.participant.vars["rfCounterbalancing"] == 0:
            if self.player.rfBreakRule:
                self.participant.vars["rfNumB"] += 1
            else:
                self.participant.vars["rfNumA"] += 1
        else:
            if self.player.rfBreakRule:
                self.participant.vars["rfNumA"] += 1
            else:
                self.participant.vars["rfNumB"] += 1

    def vars_for_template(self):
        return {
            'counterbalancing': self.participant.vars["rfCounterbalancing"],
            'imageA': 'RuleFollowing/a{}.png'.format(self.participant.vars["rfNumA"]),
            'imageB': 'RuleFollowing/b{}.png'.format(self.participant.vars["rfNumB"]),
            'remain': 31 - self.round_number
        }


class rfFinal(BasePage):
    def is_displayed(self):
        return self.participant.vars['expiry'] \
               - time.time() > 3 and not self.participant.vars[
            'timeout_happened'] and not self.participant.vars[
            'simulated'] and self.round_number == 30

    def before_next_page(self):
        self.participant.vars['game_number'] += 1
        self.player.rfCounterbalancing = self.participant.vars["rfCounterbalancing"]
        self.player.rfBreakRuleCount = sum([p.rfBreakRule for p in self.player.in_all_rounds()])
        self.participant.vars['rfBreakRuleCount'] = self.player.rfBreakRuleCount
        if self.participant.vars['game_number'] == 9:
            self.participant.vars['game_only_time_spent'] = int(time.time() - self.participant.vars['start.time'])


page_sequence = [
    rfIntro,
    rfComp,
    rfComp2,
    rfDecision,
    rfFinal
]
