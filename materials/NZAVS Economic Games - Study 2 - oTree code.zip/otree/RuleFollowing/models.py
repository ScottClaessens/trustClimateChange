from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)

# from otree.models.session import Session as BaseSession
author = 'Scott Claessens'

doc = """
Rule Following Task
"""


class Constants(BaseConstants):
    name_in_url = 'rf'
    players_per_group = None
    num_rounds = 30

    rfInstructions = 'RuleFollowing/rfInstructions.html'


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    comprehension = models.IntegerField(
        choices=[
            [1, '2 points'],
            [2, '1 point']],
        widget=widgets.RadioSelect
    )
    rfCounterbalancing = models.IntegerField()
    rfBreakRule = models.BooleanField()
    rfBreakRuleCount = models.IntegerField(initial=0)