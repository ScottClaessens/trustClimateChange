from otree.api import Currency as c, currency_range
from . import pages
from ._builtin import Bot
import random
from .models import Constants


class PlayerBot(Bot):
    def play_round(self):
        if self.round_number == 1:
            yield (pages.rfIntro)
            if random.uniform(0, 1) < 0.9:
                yield (pages.rfComp, {'comprehension': 1})
            else:
                yield (pages.rfComp, {'comprehension': 2})
            yield (pages.rfComp2)
        yield (pages.rfDecision, {'rfBreakRule': bool(random.randint(0, 1))})
        if self.round_number == 30:
            yield (pages.rfFinal)
